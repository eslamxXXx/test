#include <stdio.h>
int main()
{
  char c;
  scanf("%c",&c);
  if ((c>='a'&&c<='z')||(c>='A'&&c<='Z'))
  {
    printf("\n%c is an Alphabet\n",c );
  }
  else
  {
    printf("\n%c is not an Alphabet\n",c);
  }
}
