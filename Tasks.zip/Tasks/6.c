#include <stdio.h>
int main()
{
  int a,b;
  scanf("%d%d",&a,&b);
  int Quotient= a/b;
  int remainder= a%b;
  printf("Quotient = %d\n",Quotient);
  printf("\nremainder = %d",remainder);
}
