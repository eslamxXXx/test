#include <stdio.h>
int main()
{
  int n;
  scanf("%d",&n);
    if (n==2)
    {
      printf("%d is a prime No.\n",n );
    }
    else
    {
      for (int i =2;i<n/2+1;i++)
      {
        if (n%i==0)
        {
          printf("%d is not a prime No. \n",n );
          return 0;
        }

      }
      printf("%d is a prime No.\n",n );
    }
}
