#include <stdio.h>
int main()
{
  int n , exponent,pow=1;
  printf("Enter base & exponent: ");
  scanf("%d",&n);
  scanf("%d",&exponent);
  while (exponent!=0) {
    pow*=n;
    exponent--;
  }
  printf("Power Of %d = %d",n,pow);
}
