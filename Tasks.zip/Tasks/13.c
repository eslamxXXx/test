#include <stdio.h>
#include <math.h>
void main()
{
  float a,b,c,root1,root2,disc,imaginary;
  scanf("%f%f%f",&a,&b,&c);
  disc=b*b-4*a*c;
  if (disc>0)
  {
    root1 = (-b-sqrt(disc))/(2*a);
    root2 = (-b+sqrt(disc))/(2*a);
    printf("\nroot1 : %.2f\n root2 : %.2f\n",root1,root2);
  }
  else if (disc==0)
  {
    root1=root2=-b/(2*a);
    printf("\nroot1 : %.2f \n root2 : %.2f",root1,root2);
  }
  else
  {
    root1=root2=-b/(2*a);
    imaginary = sqrt(-disc)/(2*a);
    printf("\nTwo distinct complex roots exists: %.2f + i%.2f and %.2f - i%.2f",
    root1, imaginary, root2, imaginary);
  }
}
