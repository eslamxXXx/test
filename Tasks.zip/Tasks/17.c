#include <stdio.h>
int main()
{
  int n;
  scanf("%d",&n);
  float sum = (n*(n+1))/2;
  printf("Sum = %.2f",sum);
}
