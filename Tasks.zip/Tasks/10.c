#include <stdio.h>
int main()
{
  int x;
  scanf("%d",&x);
if (x%2==0)
{
  printf("The No. is Even");
}
else
{
  printf("The No. is odd");
}
}
