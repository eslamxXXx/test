#include <stdio.h>
void main()
{
  int n;
  scanf("%d",&n);
  printf("%d",n);
}
