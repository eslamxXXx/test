#include <stdio.h>
void main()
{
  int x,y;
  scanf("%d%d",&x,&y);
  printf("%d",x+y);
}
