#include <stdio.h>
void main()
{
    float a,b;
    scanf("%f%f",&a,&b);
    float n = a*b;
    printf("%.2f",n); 
}
